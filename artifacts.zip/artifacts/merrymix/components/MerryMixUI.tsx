import { Feather } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import React, { ReactNode } from 'react';
import { Image, ImageSourcePropType, Pressable, StyleSheet, Text, View } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { Professional } from '@/lib/merrymix-data';

export function BrandMark({ compact = false }: { compact?: boolean }) {
  const colors = useColors();
  return (
    <View style={styles.brandRow}>
      <LinearGradient colors={[colors.purple, colors.blue]} style={[styles.brandIcon, compact && styles.brandIconSmall]}>
        <Feather name="plus" size={compact ? 14 : 18} color={colors.primaryForeground} />
      </LinearGradient>
      <Text style={[styles.brandText, compact && styles.brandTextSmall, { color: colors.foreground }]}>Merry<Text style={{ color: colors.purple }}>Mix</Text></Text>
    </View>
  );
}

export function IconButton({ icon, onPress, active = false, size = 40, label }: { icon: keyof typeof Feather.glyphMap; onPress?: () => void; active?: boolean; size?: number; label?: string }) {
  const colors = useColors();
  return (
    <Pressable accessibilityLabel={label} onPress={onPress} style={({ pressed }) => [styles.iconButton, { width: size, height: size, backgroundColor: active ? colors.accent : colors.muted, opacity: pressed ? 0.72 : 1 }]}>
      <Feather name={icon} size={18} color={active ? colors.purple : colors.mutedForeground} />
    </Pressable>
  );
}

export function SectionHeader({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  const colors = useColors();
  return (
    <View style={styles.sectionHeader}>
      <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{title}</Text>
      {action ? <Pressable onPress={onAction}><Text style={[styles.sectionAction, { color: colors.purple }]}>{action}</Text></Pressable> : null}
    </View>
  );
}

export function Rating({ rating, reviews }: { rating: number; reviews?: number }) {
  const colors = useColors();
  return <View style={styles.ratingRow}><Feather name="star" size={14} color={colors.warning} /><Text style={[styles.ratingText, { color: colors.foreground }]}>{rating.toFixed(1)}</Text>{reviews ? <Text style={[styles.reviewText, { color: colors.mutedForeground }]}>({reviews})</Text> : null}</View>;
}

export function VerifiedBadge() {
  const colors = useColors();
  return <View style={[styles.verified, { backgroundColor: colors.accent }]}><Feather name="check" size={11} color={colors.cyan} /><Text style={[styles.verifiedText, { color: colors.cyan }]}>Verified</Text></View>;
}

export function PrimaryButton({ title, onPress, icon, secondary = false, compact = false }: { title: string; onPress?: () => void; icon?: keyof typeof Feather.glyphMap; secondary?: boolean; compact?: boolean }) {
  const colors = useColors();
  return <Pressable onPress={onPress} style={({ pressed }) => [styles.primaryButton, compact && styles.primaryButtonCompact, { backgroundColor: secondary ? colors.secondary : colors.primary, opacity: pressed ? 0.8 : 1 }]}><Text style={[styles.buttonText, { color: secondary ? colors.foreground : colors.primaryForeground }]}>{title}</Text>{icon ? <Feather name={icon} size={16} color={secondary ? colors.foreground : colors.primaryForeground} /> : null}</Pressable>;
}

export function CategoryPill({ label, icon, selected = false, onPress }: { label: string; icon: keyof typeof Feather.glyphMap; selected?: boolean; onPress?: () => void }) {
  const colors = useColors();
  return <Pressable onPress={onPress} style={({ pressed }) => [styles.categoryPill, { backgroundColor: selected ? colors.accent : colors.card, borderColor: selected ? colors.purple : colors.border, opacity: pressed ? 0.75 : 1 }]}><Feather name={icon} size={16} color={selected ? colors.purple : colors.mutedForeground} /><Text style={[styles.categoryText, { color: selected ? colors.foreground : colors.mutedForeground }]}>{label}</Text></Pressable>;
}

export function ProCard({ pro, onPress, onSave, saved = false, onAdd, inTeam = false }: { pro: Professional; onPress?: () => void; onSave?: () => void; saved?: boolean; onAdd?: () => void; inTeam?: boolean }) {
  const colors = useColors();
  return <Pressable onPress={onPress} style={({ pressed }) => [styles.proCard, { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.86 : 1 }]}>
    <Image source={pro.image} style={styles.proImage} />
    <View style={styles.proInfo}>
      <View style={styles.proTopLine}><Text numberOfLines={1} style={[styles.proName, { color: colors.foreground }]}>{pro.name}</Text><IconButton icon={saved ? 'bookmark' : 'bookmark'} active={saved} size={32} label={saved ? 'Remove from saved' : 'Save professional'} onPress={onSave} /></View>
      <View style={styles.proMeta}><Text style={[styles.proCategory, { color: colors.purple }]}>{pro.category}</Text><Text style={[styles.dot, { color: colors.mutedForeground }]}>•</Text><Text style={[styles.proCategory, { color: colors.mutedForeground }]}>{pro.location}</Text></View>
      <View style={styles.proBottom}><Rating rating={pro.rating} reviews={pro.reviews} /><Text style={[styles.price, { color: colors.foreground }]}>From ₹{pro.price.toLocaleString('en-IN')}</Text></View>
      {onAdd ? <Pressable onPress={onAdd} style={[styles.addTeam, { borderColor: inTeam ? colors.success : colors.border, backgroundColor: inTeam ? colors.success + '18' : colors.muted }]}><Feather name={inTeam ? 'check' : 'plus'} size={13} color={inTeam ? colors.success : colors.purple} /><Text style={[styles.addTeamText, { color: inTeam ? colors.success : colors.foreground }]}>{inTeam ? 'In your team' : 'Add to team'}</Text></Pressable> : null}
    </View>
  </Pressable>;
}

export function EmptyState({ icon, title, detail, action, onAction }: { icon: keyof typeof Feather.glyphMap; title: string; detail: string; action?: string; onAction?: () => void }) {
  const colors = useColors();
  return <View style={[styles.empty, { backgroundColor: colors.card, borderColor: colors.border }]}><View style={[styles.emptyIcon, { backgroundColor: colors.accent }]}><Feather name={icon} size={22} color={colors.purple} /></View><Text style={[styles.emptyTitle, { color: colors.foreground }]}>{title}</Text><Text style={[styles.emptyDetail, { color: colors.mutedForeground }]}>{detail}</Text>{action ? <PrimaryButton title={action} onPress={onAction} compact /> : null}</View>;
}

export function Surface({ children, style }: { children: ReactNode; style?: object }) {
  const colors = useColors();
  return <View style={[styles.surface, { backgroundColor: colors.card, borderColor: colors.border }, style]}>{children}</View>;
}

export function Avatar({ source, initials = 'MM', size = 44 }: { source?: ImageSourcePropType; initials?: string; size?: number }) {
  const colors = useColors();
  return source ? <Image source={source} style={{ width: size, height: size, borderRadius: size / 2 }} /> : <View style={[styles.avatar, { width: size, height: size, borderRadius: size / 2, backgroundColor: colors.accent }]}><Text style={[styles.avatarText, { color: colors.purple }]}>{initials}</Text></View>;
}

const styles = StyleSheet.create({
  brandRow: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  brandIcon: { width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  brandIconSmall: { width: 28, height: 28, borderRadius: 10 },
  brandText: { fontSize: 21, fontWeight: '700', letterSpacing: -0.8 },
  brandTextSmall: { fontSize: 18 },
  iconButton: { borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 },
  sectionTitle: { fontSize: 20, fontWeight: '700', letterSpacing: -0.4 },
  sectionAction: { fontSize: 13, fontWeight: '600' },
  ratingRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  ratingText: { fontSize: 13, fontWeight: '700' },
  reviewText: { fontSize: 12 },
  verified: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 7, paddingVertical: 4, borderRadius: 8 },
  verifiedText: { fontSize: 10, fontWeight: '700' },
  primaryButton: { minHeight: 48, borderRadius: 16, paddingHorizontal: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  primaryButtonCompact: { minHeight: 38, borderRadius: 13, paddingHorizontal: 14 },
  buttonText: { fontSize: 14, fontWeight: '700' },
  categoryPill: { flexDirection: 'row', alignItems: 'center', gap: 7, paddingHorizontal: 14, minHeight: 38, borderWidth: 1, borderRadius: 14 },
  categoryText: { fontSize: 12, fontWeight: '600' },
  proCard: { width: 278, borderRadius: 22, borderWidth: 1, overflow: 'hidden', marginRight: 12 },
  proImage: { width: '100%', height: 174 },
  proInfo: { padding: 14, gap: 8 },
  proTopLine: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 8 },
  proName: { fontSize: 16, fontWeight: '700', flex: 1 },
  proMeta: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  proCategory: { fontSize: 12, fontWeight: '600' },
  dot: { fontSize: 12 },
  proBottom: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  price: { fontSize: 12, fontWeight: '600' },
  addTeam: { flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-start', gap: 6, paddingHorizontal: 9, paddingVertical: 7, borderRadius: 10, borderWidth: 1 },
  addTeamText: { fontSize: 11, fontWeight: '700' },
  empty: { borderRadius: 22, borderWidth: 1, alignItems: 'center', padding: 26, gap: 10 },
  emptyIcon: { width: 48, height: 48, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  emptyTitle: { fontSize: 17, fontWeight: '700', textAlign: 'center' },
  emptyDetail: { fontSize: 13, lineHeight: 20, textAlign: 'center', maxWidth: 280, marginBottom: 4 },
  surface: { borderRadius: 22, borderWidth: 1, padding: 16 },
  avatar: { alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: 15, fontWeight: '700' },
});