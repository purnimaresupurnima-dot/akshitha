/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    text: '#F6F4FF',
    tint: '#A98AFF',
    background: '#0C0B16',
    foreground: '#F6F4FF',
    card: '#17152A',
    cardForeground: '#F6F4FF',
    primary: '#9B7BFF',
    primaryForeground: '#0C0B16',
    secondary: '#24203E',
    secondaryForeground: '#E9E3FF',
    muted: '#211E35',
    mutedForeground: '#A8A2BC',
    accent: '#312754',
    accentForeground: '#F6F4FF',
    destructive: '#F06A8B',
    destructiveForeground: '#FFFFFF',
    border: '#2D2848',
    input: '#302A4B',
    surface: '#111021',
    surfaceRaised: '#1D1A33',
    purple: '#9B7BFF',
    blue: '#5D8CFF',
    cyan: '#63D7DE',
    peach: '#FFB08A',
    success: '#72D5A5',
    warning: '#F3C36B',
    white: '#FFFFFF',
    overlay: 'rgba(12, 11, 22, 0.76)',
  },
  dark: {
    text: '#F6F4FF',
    tint: '#A98AFF',
    background: '#0C0B16',
    foreground: '#F6F4FF',
    card: '#17152A',
    cardForeground: '#F6F4FF',
    primary: '#9B7BFF',
    primaryForeground: '#0C0B16',
    secondary: '#24203E',
    secondaryForeground: '#E9E3FF',
    muted: '#211E35',
    mutedForeground: '#A8A2BC',
    accent: '#312754',
    accentForeground: '#F6F4FF',
    destructive: '#F06A8B',
    destructiveForeground: '#FFFFFF',
    border: '#2D2848',
    input: '#302A4B',
    surface: '#111021',
    surfaceRaised: '#1D1A33',
    purple: '#9B7BFF',
    blue: '#5D8CFF',
    cyan: '#63D7DE',
    peach: '#FFB08A',
    success: '#72D5A5',
    warning: '#F3C36B',
    white: '#FFFFFF',
    overlay: 'rgba(12, 11, 22, 0.76)',
  },
  radius: 22,
};

export default colors;
