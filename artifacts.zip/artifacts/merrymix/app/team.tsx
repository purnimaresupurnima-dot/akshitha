import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { IconButton, PrimaryButton, ProCard, SectionHeader, Surface } from '@/components/MerryMixUI';
import { useApp } from '@/context/AppContext';
import { useColors } from '@/hooks/useColors';
import { professionals } from '@/lib/merrymix-data';

export default function TeamScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { teamIds, removeFromTeam } = useApp();
  const team = professionals.filter((pro) => teamIds.includes(pro.id));
  const estimate = team.reduce((sum, pro) => sum + pro.price, 0);
  return <View style={[styles.root, { backgroundColor: colors.background }]}><ScrollView contentContainerStyle={[styles.content, { paddingTop: insets.top + 14, paddingBottom: 40 }]} showsVerticalScrollIndicator={false}><View style={styles.header}><View><Text style={[styles.kicker, { color: colors.cyan }]}>YOUR CREW</Text><Text style={[styles.title, { color: colors.foreground }]}>Build your event team</Text></View><IconButton icon="x" label="Close team" onPress={() => router.back()} /></View><Text style={[styles.detail, { color: colors.mutedForeground }]}>Bring every moving part into one place. You can swap anyone before you send a request.</Text><Surface style={styles.estimate}><View><Text style={[styles.estimateLabel, { color: colors.mutedForeground }]}>ESTIMATED TOTAL</Text><Text style={[styles.estimateValue, { color: colors.foreground }]}>₹{estimate.toLocaleString('en-IN')}</Text></View><View style={[styles.count, { backgroundColor: colors.accent }]}><Text style={[styles.countNumber, { color: colors.purple }]}>{team.length}</Text><Text style={[styles.countLabel, { color: colors.mutedForeground }]}>selected</Text></View></Surface><SectionHeader title="Selected professionals" />{team.length ? team.map((pro) => <View key={pro.id} style={styles.row}><View style={styles.rowCard}><ProCard pro={pro} onPress={() => router.push({ pathname: '/pro/[id]', params: { id: pro.id } })} /><IconButton icon="minus" label={`Remove ${pro.name}`} onPress={() => removeFromTeam(pro.id)} size={35} /></View></View>) : <Surface><Text style={[styles.emptyTitle, { color: colors.foreground }]}>Your team is waiting</Text><Text style={[styles.detail, { color: colors.mutedForeground }]}>Add professionals as you discover them and we’ll keep the total updated.</Text></Surface>}<PrimaryButton title="Find more professionals" secondary icon="search" onPress={() => router.push('/discover')} /><PrimaryButton title="Send team booking requests" icon="send" onPress={() => router.push('/bookings')} /></ScrollView></View>;
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { paddingHorizontal: 20, gap: 16 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  kicker: { fontSize: 10, fontWeight: '800', letterSpacing: 1.5 },
  title: { fontSize: 25, lineHeight: 30, fontWeight: '700', letterSpacing: -0.8, maxWidth: 270 },
  detail: { fontSize: 13, lineHeight: 20 },
  estimate: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  estimateLabel: { fontSize: 10, fontWeight: '800', letterSpacing: 1.2 },
  estimateValue: { fontSize: 28, fontWeight: '700', marginTop: 7 },
  count: { width: 62, height: 62, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  countNumber: { fontSize: 20, fontWeight: '800' },
  countLabel: { fontSize: 10 },
  row: { position: 'relative' },
  rowCard: { alignItems: 'flex-end' },
  emptyTitle: { fontSize: 16, fontWeight: '700', marginBottom: 6 },
});