import { Feather } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import React, { useState } from 'react';
import { Alert, Image, Modal, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { IconButton, PrimaryButton, Rating, Surface, VerifiedBadge } from '@/components/MerryMixUI';
import { useApp } from '@/context/AppContext';
import { useColors } from '@/hooks/useColors';
import { professionals } from '@/lib/merrymix-data';

export default function ProfessionalProfileScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const pro = professionals.find((item) => item.id === id) ?? professionals[0];
  const { savedIds, followedIds, teamIds, toggleSaved, toggleFollowed, addToTeam, removeFromTeam, addBooking } = useApp();
  const [showBooking, setShowBooking] = useState(false);
  const [eventType, setEventType] = useState('Wedding');
  const [date, setDate] = useState('24 Nov 2026');
  const [budget, setBudget] = useState(String(pro.price));
  const [guests, setGuests] = useState('80');
  const requestBooking = () => { addBooking({ id: Date.now().toString(), professionalId: pro.id, professionalName: pro.name, eventType, date, budget: Number(budget.replace(/[^0-9]/g, '')) || pro.price, status: 'Pending' }); setShowBooking(false); Alert.alert('Booking request sent', `${pro.name} will review your ${eventType.toLowerCase()} request.`); };
  const inTeam = teamIds.includes(pro.id);
  return <View style={[styles.root, { backgroundColor: colors.background }]}><ScrollView contentContainerStyle={[styles.content, { paddingBottom: 120 }]} showsVerticalScrollIndicator={false}><View style={styles.cover}><Image source={pro.cover} style={styles.coverImage} /><LinearGradient colors={['transparent', colors.background]} style={styles.coverFade} /><View style={[styles.coverActions, { paddingTop: insets.top + 10 }]}><IconButton icon="chevron-left" label="Go back" onPress={() => router.back()} /><View style={styles.coverRight}><IconButton icon={savedIds.includes(pro.id) ? 'bookmark' : 'bookmark'} active={savedIds.includes(pro.id)} label="Save professional" onPress={() => toggleSaved(pro.id)} /><IconButton icon="share-2" label="Share profile" /></View></View></View><View style={styles.profile}><View style={styles.nameRow}><View style={styles.nameCopy}><View style={styles.nameLine}><Text style={[styles.name, { color: colors.foreground }]}>{pro.name}</Text>{pro.verified ? <VerifiedBadge /> : null}</View><Text style={[styles.category, { color: colors.purple }]}>{pro.category} · {pro.location}</Text></View><View style={[styles.match, { backgroundColor: colors.accent }]}><Text style={[styles.matchNumber, { color: colors.purple }]}>{pro.match}%</Text><Text style={[styles.matchLabel, { color: colors.mutedForeground }]}>AI match</Text></View></View><View style={styles.stats}><View><Text style={[styles.statValue, { color: colors.foreground }]}>{pro.rating}</Text><Text style={[styles.statLabel, { color: colors.mutedForeground }]}>rating</Text></View><View><Text style={[styles.statValue, { color: colors.foreground }]}>{pro.reviews}</Text><Text style={[styles.statLabel, { color: colors.mutedForeground }]}>reviews</Text></View><View><Text style={[styles.statValue, { color: colors.foreground }]}>{pro.experience}</Text><Text style={[styles.statLabel, { color: colors.mutedForeground }]}>experience</Text></View><View><Text style={[styles.statValue, { color: colors.foreground }]}>{pro.followers}</Text><Text style={[styles.statLabel, { color: colors.mutedForeground }]}>followers</Text></View></View><View style={styles.actions}><PrimaryButton title="Request booking" icon="calendar" onPress={() => setShowBooking(true)} /><IconButton icon="message-circle" size={48} label="Chat" onPress={() => router.push({ pathname: '/chat', params: { name: pro.name } })} /><IconButton icon={followedIds.includes(pro.id) ? 'user-check' : 'user-plus'} active={followedIds.includes(pro.id)} size={48} label="Follow" onPress={() => toggleFollowed(pro.id)} /></View><Surface style={styles.recommend}><View style={[styles.spark, { backgroundColor: colors.accent }]}><Feather name="star" size={17} color={colors.purple} /></View><View style={styles.recommendCopy}><Text style={[styles.recommendKicker, { color: colors.purple }]}>WHY AI RECOMMENDS THEM</Text><Text style={[styles.recommendText, { color: colors.foreground }]}>Matches your budget, specializes in {pro.specialty.toLowerCase()}, and is available for your selected date.</Text></View></Surface><Text style={[styles.sectionTitle, { color: colors.foreground }]}>About {pro.name}</Text><Text style={[styles.bio, { color: colors.mutedForeground }]}>{pro.bio}</Text><Text style={[styles.sectionTitle, { color: colors.foreground }]}>Portfolio</Text><View style={styles.portfolio}><Image source={pro.image} style={styles.portfolioImage} /><Image source={pro.cover} style={styles.portfolioImage} /></View><View style={styles.tagRow}>{pro.tags.map((tag) => <View key={tag} style={[styles.tag, { backgroundColor: colors.muted }]}><Text style={[styles.tagText, { color: colors.mutedForeground }]}>{tag}</Text></View>)}</View><Pressable onPress={() => inTeam ? removeFromTeam(pro.id) : addToTeam(pro.id)} style={[styles.teamButton, { borderColor: inTeam ? colors.success : colors.border, backgroundColor: inTeam ? colors.success + '18' : colors.card }]}><Feather name={inTeam ? 'check' : 'plus'} size={17} color={inTeam ? colors.success : colors.purple} /><Text style={[styles.teamButtonText, { color: inTeam ? colors.success : colors.foreground }]}>{inTeam ? 'Added to your event team' : 'Add to your event team'}</Text></Pressable></View></ScrollView><Modal visible={showBooking} transparent animationType="slide" onRequestClose={() => setShowBooking(false)}><View style={[styles.modalBackdrop, { backgroundColor: colors.overlay }]}><View style={[styles.modal, { backgroundColor: colors.surface }]}><View style={styles.modalHeader}><View><Text style={[styles.modalKicker, { color: colors.purple }]}>REQUEST BOOKING</Text><Text style={[styles.modalTitle, { color: colors.foreground }]}>{pro.name}</Text></View><IconButton icon="x" label="Close booking form" onPress={() => setShowBooking(false)} /></View><Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Event type</Text><ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.typeRow}>{['Wedding', 'Birthday', 'Engagement', 'Corporate'].map((type) => <Pressable key={type} onPress={() => setEventType(type)} style={[styles.typeChip, { backgroundColor: eventType === type ? colors.accent : colors.card, borderColor: eventType === type ? colors.purple : colors.border }]}><Text style={[styles.typeText, { color: eventType === type ? colors.foreground : colors.mutedForeground }]}>{type}</Text></Pressable>)}</ScrollView><Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Event date</Text><TextInput value={date} onChangeText={setDate} placeholder="24 Nov 2026" placeholderTextColor={colors.mutedForeground} style={[styles.textField, { color: colors.foreground, backgroundColor: colors.card, borderColor: colors.border }]} /><View style={styles.fields}><View style={styles.fieldHalf}><Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Guests</Text><TextInput value={guests} onChangeText={setGuests} keyboardType="number-pad" style={[styles.textField, { color: colors.foreground, backgroundColor: colors.card, borderColor: colors.border }]} /></View><View style={styles.fieldHalf}><Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Budget</Text><TextInput value={budget} onChangeText={setBudget} keyboardType="number-pad" style={[styles.textField, { color: colors.foreground, backgroundColor: colors.card, borderColor: colors.border }]} /></View></View><View style={[styles.privateNote, { backgroundColor: colors.accent }]}><Feather name="shield" size={14} color={colors.cyan} /><Text style={[styles.privateText, { color: colors.mutedForeground }]}>Your exact location is only shared after this request is accepted.</Text></View><PrimaryButton title="Send booking request" icon="send" onPress={requestBooking} /></View></View></Modal></View>;
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { gap: 16 },
  cover: { height: 278, position: 'relative' },
  coverImage: { width: '100%', height: '100%' },
  coverFade: { ...StyleSheet.absoluteFillObject, top: '35%' },
  coverActions: { position: 'absolute', left: 16, right: 16, flexDirection: 'row', justifyContent: 'space-between' },
  coverRight: { flexDirection: 'row', gap: 8 },
  profile: { paddingHorizontal: 20, gap: 16, marginTop: -19 },
  nameRow: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: 10 },
  nameCopy: { flex: 1, gap: 5 },
  nameLine: { flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' },
  name: { fontSize: 25, fontWeight: '700', letterSpacing: -0.8 },
  category: { fontSize: 13, fontWeight: '600' },
  match: { width: 61, height: 61, borderRadius: 20, justifyContent: 'center', alignItems: 'center' },
  matchNumber: { fontSize: 16, fontWeight: '800' },
  matchLabel: { fontSize: 9 },
  stats: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 2 },
  statValue: { fontSize: 15, fontWeight: '700', textAlign: 'center' },
  statLabel: { fontSize: 10, textAlign: 'center', marginTop: 3 },
  actions: { flexDirection: 'row', gap: 9, alignItems: 'center' },
  recommend: { flexDirection: 'row', gap: 11, padding: 13 },
  spark: { width: 36, height: 36, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  recommendCopy: { flex: 1, gap: 5 },
  recommendKicker: { fontSize: 10, fontWeight: '800', letterSpacing: 1.2 },
  recommendText: { fontSize: 12, lineHeight: 18 },
  sectionTitle: { fontSize: 18, fontWeight: '700', marginTop: 3 },
  bio: { fontSize: 13, lineHeight: 20, marginTop: -8 },
  portfolio: { flexDirection: 'row', gap: 10 },
  portfolioImage: { width: '48.5%', height: 156, borderRadius: 18 },
  tagRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 7, marginTop: -6 },
  tag: { paddingHorizontal: 10, paddingVertical: 7, borderRadius: 10 },
  tagText: { fontSize: 11, fontWeight: '600' },
  teamButton: { minHeight: 49, borderRadius: 16, borderWidth: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  teamButtonText: { fontSize: 13, fontWeight: '700' },
  modalBackdrop: { flex: 1, justifyContent: 'flex-end' },
  modal: { borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 20, gap: 13 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 3 },
  modalKicker: { fontSize: 10, fontWeight: '800', letterSpacing: 1.4 },
  modalTitle: { fontSize: 21, fontWeight: '700', marginTop: 4 },
  inputLabel: { fontSize: 11, fontWeight: '600', marginBottom: -5 },
  typeRow: { gap: 7 },
  typeChip: { borderWidth: 1, borderRadius: 11, paddingHorizontal: 11, paddingVertical: 8 },
  typeText: { fontSize: 11, fontWeight: '600' },
  textField: { minHeight: 46, borderWidth: 1, borderRadius: 14, paddingHorizontal: 13, fontSize: 13 },
  fields: { flexDirection: 'row', gap: 10 },
  fieldHalf: { flex: 1, gap: 8 },
  privateNote: { flexDirection: 'row', gap: 7, alignItems: 'center', padding: 10, borderRadius: 12 },
  privateText: { fontSize: 10, lineHeight: 15, flex: 1 },
});