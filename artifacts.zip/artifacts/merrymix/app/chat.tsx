import { Feather } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Avatar, IconButton } from '@/components/MerryMixUI';
import { useColors } from '@/hooks/useColors';

export default function ChatScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ name?: string }>();
  const name = typeof params.name === 'string' ? params.name : 'Royal Moments';
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([{ text: 'Hi Ananya, your date looks lovely for a midnight garden celebration.', mine: false }, { text: 'That sounds perfect. Can you share a few portfolio references?', mine: true }]);
  const send = () => { if (!message.trim()) return; setMessages((current) => [...current, { text: message.trim(), mine: true }]); setMessage(''); };
  return <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={[styles.root, { backgroundColor: colors.background }]}><View style={[styles.header, { paddingTop: insets.top + 10, borderBottomColor: colors.border }]}><IconButton icon="chevron-left" label="Go back" onPress={() => router.back()} /><Avatar initials={name.slice(0, 2).toUpperCase()} size={38} /><View style={styles.headerCopy}><Text style={[styles.name, { color: colors.foreground }]}>{name}</Text><Text style={[styles.status, { color: colors.success }]}>Typically replies in 1 hour</Text></View><IconButton icon="more-horizontal" label="More options" /></View><ScrollView contentContainerStyle={styles.messages} showsVerticalScrollIndicator={false}>{messages.map((item, index) => <View key={`${item.text}-${index}`} style={[styles.bubble, item.mine ? [styles.mine, { backgroundColor: colors.primary }] : [styles.theirs, { backgroundColor: colors.card, borderColor: colors.border }]]}><Text style={[styles.bubbleText, { color: item.mine ? colors.primaryForeground : colors.foreground }]}>{item.text}</Text><Text style={[styles.time, { color: item.mine ? colors.primaryForeground : colors.mutedForeground }]}>10:4{index}</Text></View>)}<View style={[styles.systemNote, { backgroundColor: colors.accent }]}><Feather name="shield" size={13} color={colors.cyan} /><Text style={[styles.systemText, { color: colors.mutedForeground }]}>Keep payments and private location details inside MerryMix.</Text></View></ScrollView><View style={[styles.composer, { paddingBottom: Math.max(insets.bottom, 12), backgroundColor: colors.background, borderTopColor: colors.border }]}><Pressable style={[styles.attach, { backgroundColor: colors.muted }]}><Feather name="paperclip" size={17} color={colors.mutedForeground} /></Pressable><TextInput value={message} onChangeText={setMessage} placeholder="Write a message..." placeholderTextColor={colors.mutedForeground} style={[styles.textInput, { color: colors.foreground, backgroundColor: colors.card }]} onSubmitEditing={send} returnKeyType="send" /><Pressable onPress={send} style={[styles.send, { backgroundColor: colors.primary }]}><Feather name="arrow-up" size={18} color={colors.primaryForeground} /></Pressable></View></KeyboardAvoidingView>;
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: { paddingHorizontal: 16, paddingBottom: 12, flexDirection: 'row', alignItems: 'center', gap: 10, borderBottomWidth: 1 },
  headerCopy: { flex: 1, gap: 3 },
  name: { fontSize: 15, fontWeight: '700' },
  status: { fontSize: 10 },
  messages: { padding: 20, gap: 12, flexGrow: 1, justifyContent: 'flex-end' },
  bubble: { maxWidth: '82%', padding: 13, borderRadius: 18, gap: 6 },
  mine: { alignSelf: 'flex-end', borderBottomRightRadius: 5 },
  theirs: { alignSelf: 'flex-start', borderWidth: 1, borderBottomLeftRadius: 5 },
  bubbleText: { fontSize: 14, lineHeight: 20 },
  time: { fontSize: 9, alignSelf: 'flex-end', opacity: 0.8 },
  systemNote: { alignSelf: 'center', flexDirection: 'row', alignItems: 'center', gap: 7, paddingHorizontal: 11, paddingVertical: 8, borderRadius: 10, marginTop: 8 },
  systemText: { fontSize: 10, maxWidth: 250, textAlign: 'center' },
  composer: { paddingHorizontal: 14, paddingTop: 10, flexDirection: 'row', alignItems: 'center', gap: 8, borderTopWidth: 1 },
  attach: { width: 40, height: 40, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  textInput: { flex: 1, minHeight: 42, borderRadius: 15, paddingHorizontal: 14, fontSize: 13 },
  send: { width: 40, height: 40, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
});