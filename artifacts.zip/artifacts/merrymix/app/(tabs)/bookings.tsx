import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { EmptyState, IconButton, PrimaryButton, SectionHeader, Surface } from '@/components/MerryMixUI';
import { useApp } from '@/context/AppContext';
import { useColors } from '@/hooks/useColors';

export default function BookingsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { bookings, plan } = useApp();
  return <View style={[styles.root, { backgroundColor: colors.background }]}><ScrollView contentContainerStyle={[styles.content, { paddingTop: insets.top + 16, paddingBottom: 116 }]} showsVerticalScrollIndicator={false}><View style={styles.header}><View><Text style={[styles.kicker, { color: colors.purple }]}>YOUR EVENTS</Text><Text style={[styles.title, { color: colors.foreground }]}>Bookings</Text></View><IconButton icon="bell" label="Notifications" /></View>{plan ? <Surface style={styles.eventCard}><View style={[styles.eventIcon, { backgroundColor: colors.accent }]}><Feather name="calendar" size={18} color={colors.purple} /></View><View style={styles.eventCopy}><Text style={[styles.eventLabel, { color: colors.purple }]}>MERRY MIX PLAN</Text><Text style={[styles.eventTitle, { color: colors.foreground }]}>{plan.eventType} · {plan.guests} guests</Text><Text style={[styles.eventDetail, { color: colors.mutedForeground }]}>{plan.location} · ₹{plan.budget.toLocaleString('en-IN')}</Text></View><Feather name="chevron-right" size={18} color={colors.mutedForeground} /></Surface> : null}<SectionHeader title={`${bookings.length} booking requests`} action="Help" />{bookings.length ? bookings.map((booking) => <Surface key={booking.id} style={styles.booking}><View style={styles.bookingTop}><View><Text style={[styles.bookingPro, { color: colors.foreground }]}>{booking.professionalName}</Text><Text style={[styles.bookingEvent, { color: colors.mutedForeground }]}>{booking.eventType} · {booking.date}</Text></View><View style={[styles.status, { backgroundColor: booking.status === 'Accepted' ? colors.success + '1F' : colors.accent }]}><Text style={[styles.statusText, { color: booking.status === 'Accepted' ? colors.success : colors.purple }]}>{booking.status}</Text></View></View><View style={styles.bookingBottom}><Text style={[styles.budgetLabel, { color: colors.mutedForeground }]}>Budget</Text><Text style={[styles.budgetValue, { color: colors.foreground }]}>₹{booking.budget.toLocaleString('en-IN')}</Text><View style={styles.spacer} /><IconButton icon="message-circle" size={34} label="Chat with professional" onPress={() => router.push({ pathname: '/chat', params: { name: booking.professionalName } })} /></View></Surface>) : <EmptyState icon="calendar" title="Your next big moment starts here." detail="When you request a booking, you’ll see every detail and status in one calm place." action="Discover professionals" onAction={() => router.push('/discover')} />}<PrimaryButton title="Plan another event with AI" secondary onPress={() => router.push('/planner')} /></ScrollView></View>;
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { paddingHorizontal: 20, gap: 16 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  kicker: { fontSize: 10, fontWeight: '800', letterSpacing: 1.5 },
  title: { fontSize: 28, fontWeight: '700', letterSpacing: -1 },
  eventCard: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14 },
  eventIcon: { width: 40, height: 40, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  eventCopy: { flex: 1, gap: 4 },
  eventLabel: { fontSize: 10, fontWeight: '800', letterSpacing: 1 },
  eventTitle: { fontSize: 14, fontWeight: '700' },
  eventDetail: { fontSize: 11 },
  booking: { gap: 16 },
  bookingTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 },
  bookingPro: { fontSize: 16, fontWeight: '700' },
  bookingEvent: { fontSize: 12, marginTop: 5 },
  status: { paddingHorizontal: 9, paddingVertical: 6, borderRadius: 9 },
  statusText: { fontSize: 11, fontWeight: '700' },
  bookingBottom: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  budgetLabel: { fontSize: 12 },
  budgetValue: { fontSize: 13, fontWeight: '700' },
  spacer: { flex: 1 },
});