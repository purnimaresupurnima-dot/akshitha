import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React from 'react';
import { Image, Pressable, ScrollView, StyleSheet, Switch, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { BrandMark, IconButton, ProCard, SectionHeader, Surface } from '@/components/MerryMixUI';
import { useApp } from '@/context/AppContext';
import { useColors } from '@/hooks/useColors';
import { professionals } from '@/lib/merrymix-data';

export default function ProfileScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { savedIds, teamIds, bookings, themeMode, toggleTheme } = useApp();
  const saved = professionals.filter((pro) => savedIds.includes(pro.id));
  return <View style={[styles.root, { backgroundColor: colors.background }]}><ScrollView contentContainerStyle={[styles.content, { paddingTop: insets.top + 16, paddingBottom: 116 }]} showsVerticalScrollIndicator={false}><View style={styles.header}><BrandMark /><IconButton icon="settings" label="Settings" onPress={() => undefined} /></View><View style={styles.profileHero}><View style={[styles.avatar, { backgroundColor: colors.accent }]}><Text style={[styles.avatarText, { color: colors.purple }]}>AS</Text></View><View style={styles.profileCopy}><Text style={[styles.profileName, { color: colors.foreground }]}>Ananya Sharma</Text><Text style={[styles.profileMeta, { color: colors.mutedForeground }]}>Event dreamer · Hyderabad</Text><View style={styles.profileStats}><Text style={[styles.stat, { color: colors.foreground }]}>{bookings.length} <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>bookings</Text></Text><Text style={[styles.stat, { color: colors.foreground }]}>{savedIds.length} <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>saved</Text></Text><Text style={[styles.stat, { color: colors.foreground }]}>{teamIds.length} <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>team</Text></Text></View></View><IconButton icon="edit-2" label="Edit profile" /></View><Surface style={styles.aiCard}><View style={[styles.aiIcon, { backgroundColor: colors.accent }]}><Feather name="star" size={18} color={colors.purple} /></View><View style={styles.aiCopy}><Text style={[styles.aiTitle, { color: colors.foreground }]}>Your event co-pilot is ready</Text><Text style={[styles.aiDetail, { color: colors.mutedForeground }]}>Pick up your latest plan or start something new.</Text></View><Pressable onPress={() => router.push('/planner')}><Feather name="arrow-up-right" size={18} color={colors.purple} /></Pressable></Surface><SectionHeader title="Your space" /><View style={[styles.menu, { backgroundColor: colors.card, borderColor: colors.border }]}><Pressable onPress={() => router.push('/team')} style={styles.menuRow}><View style={[styles.menuIcon, { backgroundColor: colors.accent }]}><Feather name="users" size={17} color={colors.cyan} /></View><View style={styles.menuCopy}><Text style={[styles.menuTitle, { color: colors.foreground }]}>My event team</Text><Text style={[styles.menuDetail, { color: colors.mutedForeground }]}>{teamIds.length} professionals selected</Text></View><Feather name="chevron-right" size={17} color={colors.mutedForeground} /></Pressable><Pressable onPress={() => router.push('/bookings')} style={styles.menuRow}><View style={[styles.menuIcon, { backgroundColor: colors.accent }]}><Feather name="calendar" size={17} color={colors.purple} /></View><View style={styles.menuCopy}><Text style={[styles.menuTitle, { color: colors.foreground }]}>My bookings</Text><Text style={[styles.menuDetail, { color: colors.mutedForeground }]}>{bookings.length} requests in progress</Text></View><Feather name="chevron-right" size={17} color={colors.mutedForeground} /></Pressable><View style={styles.menuRow}><View style={[styles.menuIcon, { backgroundColor: colors.accent }]}><Feather name={themeMode === 'dark' ? 'moon' : 'sun'} size={17} color={colors.warning} /></View><View style={styles.menuCopy}><Text style={[styles.menuTitle, { color: colors.foreground }]}>Dark mode</Text><Text style={[styles.menuDetail, { color: colors.mutedForeground }]}>A calmer way to plan at night</Text></View><Switch value={themeMode === 'dark'} onValueChange={toggleTheme} trackColor={{ false: colors.muted, true: colors.purple }} thumbColor={colors.white} /></View></View><SectionHeader title="Saved professionals" action={saved.length ? 'View all' : undefined} />{saved.length ? saved.slice(0, 2).map((pro) => <ProCard key={pro.id} pro={pro} onPress={() => router.push({ pathname: '/pro/[id]', params: { id: pro.id } })} saved />) : <Surface style={styles.savedEmpty}><Feather name="bookmark" size={20} color={colors.purple} /><Text style={[styles.savedTitle, { color: colors.foreground }]}>Nothing saved yet</Text><Text style={[styles.savedDetail, { color: colors.mutedForeground }]}>Tap the bookmark on a professional to keep them close.</Text></Surface>}<Text style={[styles.version, { color: colors.mutedForeground }]}>MerryMix · made for moments that matter</Text></ScrollView></View>;
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { paddingHorizontal: 20, gap: 16 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  profileHero: { flexDirection: 'row', alignItems: 'center', gap: 13, paddingVertical: 6 },
  avatar: { width: 64, height: 64, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: 22, fontWeight: '800' },
  profileCopy: { flex: 1, gap: 4 },
  profileName: { fontSize: 19, fontWeight: '700' },
  profileMeta: { fontSize: 12 },
  profileStats: { flexDirection: 'row', gap: 13, marginTop: 4 },
  stat: { fontSize: 12, fontWeight: '700' },
  statLabel: { fontSize: 11, fontWeight: '400' },
  aiCard: { flexDirection: 'row', alignItems: 'center', gap: 11, padding: 13 },
  aiIcon: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  aiCopy: { flex: 1, gap: 4 },
  aiTitle: { fontSize: 13, fontWeight: '700' },
  aiDetail: { fontSize: 11, lineHeight: 16 },
  menu: { borderWidth: 1, borderRadius: 22, overflow: 'hidden' },
  menuRow: { minHeight: 72, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, gap: 11, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.06)' },
  menuIcon: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  menuCopy: { flex: 1, gap: 4 },
  menuTitle: { fontSize: 13, fontWeight: '700' },
  menuDetail: { fontSize: 11 },
  savedEmpty: { alignItems: 'center', gap: 8 },
  savedTitle: { fontSize: 15, fontWeight: '700' },
  savedDetail: { fontSize: 12, textAlign: 'center', lineHeight: 18 },
  version: { textAlign: 'center', fontSize: 11, marginTop: 6 },
});