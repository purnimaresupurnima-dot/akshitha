import { Feather } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import React from 'react';
import { Image, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useApp } from '@/context/AppContext';
import { useColors } from '@/hooks/useColors';
import { categories, professionals } from '@/lib/merrymix-data';
import { BrandMark, CategoryPill, IconButton, ProCard, SectionHeader, Surface } from '@/components/MerryMixUI';

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { savedIds, teamIds, plan } = useApp();

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={[styles.content, { paddingTop: insets.top + 18, paddingBottom: 116 }]} showsVerticalScrollIndicator={false}>
        <View style={styles.header}><BrandMark /><View style={styles.headerActions}><IconButton icon="bell" label="Notifications" onPress={() => router.push('/bookings')} /><IconButton icon="user" label="Open profile" onPress={() => router.push('/profile')} /></View></View>
        <View style={styles.hello}><Text style={[styles.eyebrow, { color: colors.purple }]}>GOOD EVENING, ANANYA</Text><Text style={[styles.title, { color: colors.foreground }]}>Make it a moment{'\n'}worth remembering.</Text></View>
        <LinearGradient colors={[colors.purple, colors.blue]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.heroCard}>
          <View style={styles.heroGlow} /><View style={styles.heroCopy}><Text style={[styles.heroKicker, { color: colors.primaryForeground }]}>MERRYMIX AI</Text><Text style={[styles.heroTitle, { color: colors.primaryForeground }]}>Your event,{'\n'}beautifully planned.</Text><Text style={[styles.heroDetail, { color: colors.primaryForeground }]}>Tell us the feeling you want. We’ll shape the details around it.</Text><Pressable onPress={() => router.push('/planner')} style={({ pressed }) => [styles.heroButton, { opacity: pressed ? 0.8 : 1 }]}><Text style={[styles.heroButtonText, { color: colors.purple }]}>Plan with AI</Text><Feather name="arrow-up-right" size={15} color={colors.purple} /></Pressable></View>
          <View style={styles.heroVisual}><Image source={require('../../assets/images/celebration.jpg')} style={styles.heroImage} /><View style={[styles.heroBadge, { backgroundColor: colors.surface }]}><Feather name="star" size={14} color={colors.warning} /><Text style={[styles.heroBadgeText, { color: colors.foreground }]}>94% match</Text></View></View>
        </LinearGradient>
        <View style={styles.searchBox}><Feather name="search" size={18} color={colors.mutedForeground} /><Text style={[styles.searchPlaceholder, { color: colors.mutedForeground }]}>What are you looking for?</Text><Pressable onPress={() => router.push('/discover')}><Feather name="sliders" size={17} color={colors.purple} /></Pressable></View>
        <SectionHeader title="Explore by mood" action="See all" onAction={() => router.push('/discover')} />
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.pills}>
          {categories.slice(0, 5).map((category) => <CategoryPill key={category.name} label={category.name} icon={category.icon as keyof typeof Feather.glyphMap} onPress={() => router.push({ pathname: '/discover', params: { category: category.name } })} />)}
        </ScrollView>
        <SectionHeader title="Trending near you" action="View all" onAction={() => router.push('/discover')} />
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.horizontal}>
          {professionals.slice(0, 4).map((pro) => <ProCard key={pro.id} pro={pro} saved={savedIds.includes(pro.id)} onSave={() => undefined} onPress={() => router.push({ pathname: '/pro/[id]', params: { id: pro.id } })} onAdd={() => undefined} inTeam={teamIds.includes(pro.id)} />)}
        </ScrollView>
        <Surface style={styles.teamCard}>
          <View style={styles.teamIcon}><Feather name="users" size={20} color={colors.cyan} /></View><View style={styles.teamCopy}><Text style={[styles.teamTitle, { color: colors.foreground }]}>Build your event team</Text><Text style={[styles.teamDetail, { color: colors.mutedForeground }]}>{teamIds.length} professionals selected · {plan ? 'Your plan is ready' : 'Start with a recommendation'}</Text></View><Pressable onPress={() => router.push('/team')}><Feather name="arrow-right" size={18} color={colors.purple} /></Pressable>
        </Surface>
        <SectionHeader title="A little inspiration" action="Discover" onAction={() => router.push('/discover')} />
        <View style={styles.inspiration}><Image source={require('../../assets/images/decoration.jpg')} style={styles.inspirationImage} /><View style={styles.inspirationOverlay}><Text style={[styles.inspirationKicker, { color: colors.warning }]}>THEME OF THE WEEK</Text><Text style={[styles.inspirationTitle, { color: colors.white }]}>Midnight garden</Text><Text style={[styles.inspirationDetail, { color: colors.white }]}>Indigo florals · Candlelight · Silk details</Text></View></View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { paddingHorizontal: 20, gap: 18 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  headerActions: { flexDirection: 'row', gap: 8 },
  hello: { gap: 6, marginTop: 10 },
  eyebrow: { fontSize: 10, fontWeight: '800', letterSpacing: 1.6 },
  title: { fontSize: 30, lineHeight: 35, fontWeight: '700', letterSpacing: -1.2 },
  heroCard: { borderRadius: 26, minHeight: 240, overflow: 'hidden', flexDirection: 'row', padding: 18, gap: 8 },
  heroGlow: { position: 'absolute', width: 190, height: 190, borderRadius: 95, right: 80, top: -70, backgroundColor: 'rgba(255,255,255,0.14)' },
  heroCopy: { flex: 1, justifyContent: 'space-between', paddingVertical: 5, zIndex: 1 },
  heroKicker: { fontSize: 10, fontWeight: '800', letterSpacing: 1.7 },
  heroTitle: { fontSize: 24, lineHeight: 27, fontWeight: '700', letterSpacing: -0.8, marginTop: 10 },
  heroDetail: { fontSize: 12, lineHeight: 18, opacity: 0.85, marginTop: 8 },
  heroButton: { alignSelf: 'flex-start', backgroundColor: 'rgba(255,255,255,0.94)', minHeight: 38, borderRadius: 13, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 14 },
  heroButtonText: { fontSize: 12, fontWeight: '800' },
  heroVisual: { width: 118, alignItems: 'center', justifyContent: 'center' },
  heroImage: { width: 110, height: 170, borderRadius: 54, transform: [{ rotate: '5deg' }], opacity: 0.9 },
  heroBadge: { flexDirection: 'row', gap: 5, alignItems: 'center', paddingHorizontal: 8, paddingVertical: 6, borderRadius: 10, position: 'absolute', bottom: 15, left: -5 },
  heroBadgeText: { fontSize: 10, fontWeight: '700' },
  searchBox: { minHeight: 52, borderRadius: 17, backgroundColor: 'rgba(255,255,255,0.04)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)', flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 15 },
  searchPlaceholder: { fontSize: 13, flex: 1 },
  pills: { gap: 8, paddingBottom: 2 },
  horizontal: { paddingBottom: 3 },
  teamCard: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14 },
  teamIcon: { width: 40, height: 40, borderRadius: 14, backgroundColor: 'rgba(99,215,222,0.12)', alignItems: 'center', justifyContent: 'center' },
  teamCopy: { flex: 1, gap: 4 },
  teamTitle: { fontSize: 14, fontWeight: '700' },
  teamDetail: { fontSize: 11 },
  inspiration: { height: 185, borderRadius: 23, overflow: 'hidden' },
  inspirationImage: { width: '100%', height: '100%' },
  inspirationOverlay: { ...StyleSheet.absoluteFillObject, justifyContent: 'flex-end', padding: 18, backgroundColor: 'rgba(12,11,22,0.32)' },
  inspirationKicker: { fontSize: 10, letterSpacing: 1.5, fontWeight: '800' },
  inspirationTitle: { fontSize: 23, fontWeight: '700', marginTop: 5 },
  inspirationDetail: { fontSize: 12, opacity: 0.84, marginTop: 4 },
});
