import { Feather } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { BrandMark, CategoryPill, IconButton, ProCard, SectionHeader } from '@/components/MerryMixUI';
import { useApp } from '@/context/AppContext';
import { useColors } from '@/hooks/useColors';
import { categories, professionals } from '@/lib/merrymix-data';

export default function DiscoverScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ category?: string }>();
  const initialCategory = typeof params.category === 'string' ? params.category : 'All';
  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState(initialCategory);
  const { savedIds, teamIds, toggleSaved, addToTeam, removeFromTeam } = useApp();
  const filtered = useMemo(() => professionals.filter((pro) => {
    const matchesCategory = activeCategory === 'All' || pro.category.toLowerCase().includes(activeCategory.toLowerCase());
    const matchesQuery = !query.trim() || `${pro.name} ${pro.category} ${pro.location} ${pro.specialty}`.toLowerCase().includes(query.toLowerCase());
    return matchesCategory && matchesQuery;
  }), [activeCategory, query]);

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={[styles.content, { paddingTop: insets.top + 16, paddingBottom: 116 }]} showsVerticalScrollIndicator={false}>
        <View style={styles.header}><View><Text style={[styles.kicker, { color: colors.purple }]}>DISCOVER</Text><Text style={[styles.title, { color: colors.foreground }]}>Find your people.</Text></View><View style={styles.headerActions}><IconButton icon="bell" label="Notifications" onPress={() => router.push('/bookings')} /><BrandMark compact /></View></View>
        <View style={[styles.search, { backgroundColor: colors.card, borderColor: colors.border }]}><Feather name="search" size={18} color={colors.mutedForeground} /><TextInput value={query} onChangeText={setQuery} placeholder="Try “wedding photographer”" placeholderTextColor={colors.mutedForeground} style={[styles.input, { color: colors.foreground }]} /><Pressable onPress={() => setQuery('')}><Feather name={query ? 'x' : 'sliders'} size={17} color={colors.purple} /></Pressable></View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chips}><CategoryPill label="All" icon="grid" selected={activeCategory === 'All'} onPress={() => setActiveCategory('All')} />{categories.map((category) => <CategoryPill key={category.name} label={category.name} icon={category.icon as keyof typeof Feather.glyphMap} selected={activeCategory === category.name} onPress={() => setActiveCategory(category.name)} />)}</ScrollView>
        <View style={styles.aiSearch}><View style={[styles.aiSpark, { backgroundColor: colors.accent }]}><Feather name="star" size={17} color={colors.purple} /></View><View style={styles.aiCopy}><Text style={[styles.aiTitle, { color: colors.foreground }]}>Let AI find the right fit</Text><Text style={[styles.aiDetail, { color: colors.mutedForeground }]}>“Photographer near Hyderabad under ₹20k”</Text></View><Pressable onPress={() => router.push('/planner')}><Feather name="arrow-up-right" size={18} color={colors.purple} /></Pressable></View>
        <SectionHeader title={`${filtered.length} professionals`} action="Recommended" />
        {filtered.length ? filtered.map((pro) => <View key={pro.id} style={styles.listItem}><ProCard pro={pro} saved={savedIds.includes(pro.id)} onSave={() => toggleSaved(pro.id)} onPress={() => router.push({ pathname: '/pro/[id]', params: { id: pro.id } })} onAdd={() => teamIds.includes(pro.id) ? removeFromTeam(pro.id) : addToTeam(pro.id)} inTeam={teamIds.includes(pro.id)} /></View>) : <View style={[styles.noResults, { backgroundColor: colors.card, borderColor: colors.border }]}><Feather name="search" size={24} color={colors.purple} /><Text style={[styles.noTitle, { color: colors.foreground }]}>No perfect match yet</Text><Text style={[styles.noDetail, { color: colors.mutedForeground }]}>Try a different service, city, or ask MerryMix AI.</Text></View>}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { paddingHorizontal: 20, gap: 16 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 12 },
  headerActions: { alignItems: 'flex-end', gap: 10 },
  kicker: { fontSize: 10, fontWeight: '800', letterSpacing: 1.5 },
  title: { fontSize: 28, fontWeight: '700', letterSpacing: -1 },
  search: { minHeight: 54, borderWidth: 1, borderRadius: 17, flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 14 },
  input: { flex: 1, fontSize: 13, minHeight: 50 },
  chips: { gap: 8 },
  aiSearch: { borderRadius: 18, borderWidth: 1, borderColor: 'rgba(155,123,255,0.34)', backgroundColor: 'rgba(155,123,255,0.08)', flexDirection: 'row', alignItems: 'center', gap: 11, padding: 12 },
  aiSpark: { width: 35, height: 35, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  aiCopy: { flex: 1, gap: 4 },
  aiTitle: { fontSize: 13, fontWeight: '700' },
  aiDetail: { fontSize: 11 },
  listItem: { marginBottom: 2 },
  noResults: { minHeight: 180, borderWidth: 1, borderRadius: 22, alignItems: 'center', justifyContent: 'center', padding: 24, gap: 9 },
  noTitle: { fontSize: 17, fontWeight: '700' },
  noDetail: { fontSize: 13, textAlign: 'center' },
});