import { Feather } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import React, { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { CategoryPill, IconButton, PrimaryButton, ProCard, SectionHeader, Surface } from '@/components/MerryMixUI';
import { useApp } from '@/context/AppContext';
import { useColors } from '@/hooks/useColors';
import { defaultPlan, eventTypes, professionals, EventPlan } from '@/lib/merrymix-data';

export default function PlannerScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { plan, savePlan } = useApp();
  const [prompt, setPrompt] = useState('A birthday party for 80 people with decoration, catering, photography and music.');
  const [eventType, setEventType] = useState(plan?.eventType ?? 'Birthday');
  const [result, setResult] = useState<EventPlan | null>(plan);
  const [checked, setChecked] = useState<Record<string, boolean>>({});

  const generate = () => {
    const nextPlan: EventPlan = { ...defaultPlan, eventType, location: eventType === 'Corporate' ? 'Bengaluru' : 'Hyderabad', theme: eventType === 'Wedding' ? 'Royal indigo' : 'Midnight garden' };
    savePlan(nextPlan);
    setResult(nextPlan);
  };

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={[styles.content, { paddingTop: insets.top + 14, paddingBottom: 116 }]} showsVerticalScrollIndicator={false}>
        <View style={styles.header}><View><Text style={[styles.kicker, { color: colors.purple }]}>MERRYMIX AI</Text><Text style={[styles.title, { color: colors.foreground }]}>Let’s make a plan.</Text></View><IconButton icon="x" label="Close planner" onPress={() => router.back()} /></View>
        {!result ? <><LinearGradient colors={[colors.accent, colors.secondary]} style={styles.intro}><View style={styles.introIcon}><Feather name="star" size={21} color={colors.purple} /></View><Text style={[styles.introTitle, { color: colors.foreground }]}>Describe the feeling, we’ll handle the details.</Text><Text style={[styles.introDetail, { color: colors.mutedForeground }]}>MerryMix AI creates a plan, budget, timeline, checklist, and professional matches in seconds.</Text></LinearGradient><Text style={[styles.label, { color: colors.foreground }]}>What are you planning?</Text><ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.pills}>{eventTypes.map((type) => <CategoryPill key={type} label={type} icon="calendar" selected={eventType === type} onPress={() => setEventType(type)} />)}</ScrollView><TextInput value={prompt} onChangeText={setPrompt} multiline placeholder="Tell MerryMix what you have in mind..." placeholderTextColor={colors.mutedForeground} style={[styles.prompt, { color: colors.foreground, backgroundColor: colors.card, borderColor: colors.border }]} /><View style={styles.metaRow}><View style={styles.meta}><Feather name="map-pin" size={14} color={colors.mutedForeground} /><Text style={[styles.metaText, { color: colors.mutedForeground }]}>Hyderabad</Text></View><View style={styles.meta}><Feather name="users" size={14} color={colors.mutedForeground} /><Text style={[styles.metaText, { color: colors.mutedForeground }]}>80 guests</Text></View><View style={styles.meta}><Feather name="credit-card" size={14} color={colors.mutedForeground} /><Text style={[styles.metaText, { color: colors.mutedForeground }]}>₹1,00,000</Text></View></View><PrimaryButton title="Create my event plan" icon="arrow-right" onPress={generate} /></> : <View style={styles.result}><View style={styles.resultTop}><View><Text style={[styles.kicker, { color: colors.cyan }]}>YOUR PLAN IS READY</Text><Text style={[styles.resultTitle, { color: colors.foreground }]}>{result.eventType} in {result.location}</Text></View><View style={[styles.match, { backgroundColor: colors.accent }]}><Text style={[styles.matchNumber, { color: colors.purple }]}>94%</Text><Text style={[styles.matchLabel, { color: colors.mutedForeground }]}>fit</Text></View></View><Surface><Text style={[styles.cardKicker, { color: colors.purple }]}>ESTIMATED BUDGET</Text><Text style={[styles.budget, { color: colors.foreground }]}>₹{result.budget.toLocaleString('en-IN')}</Text><View style={styles.budgetLine}><Text style={[styles.budgetLabel, { color: colors.mutedForeground }]}>Decoration</Text><Text style={[styles.budgetValue, { color: colors.foreground }]}>₹25,000</Text></View><View style={styles.budgetLine}><Text style={[styles.budgetLabel, { color: colors.mutedForeground }]}>Catering</Text><Text style={[styles.budgetValue, { color: colors.foreground }]}>₹35,000</Text></View><View style={styles.budgetLine}><Text style={[styles.budgetLabel, { color: colors.mutedForeground }]}>Photo + music</Text><Text style={[styles.budgetValue, { color: colors.foreground }]}>₹25,000</Text></View><View style={[styles.progress, { backgroundColor: colors.muted }]}><View style={[styles.progressFill, { backgroundColor: colors.purple, width: '82%' }]} /></View></Surface><SectionHeader title="Your checklist" action="Edit" /><Surface>{result.checklist.map((item) => <Pressable key={item} onPress={() => setChecked((current) => ({ ...current, [item]: !current[item] }))} style={styles.checkRow}><View style={[styles.checkbox, { borderColor: checked[item] ? colors.success : colors.border, backgroundColor: checked[item] ? colors.success : 'transparent' }]}>{checked[item] ? <Feather name="check" size={13} color={colors.background} /> : null}</View><Text style={[styles.checkText, { color: checked[item] ? colors.mutedForeground : colors.foreground, textDecorationLine: checked[item] ? 'line-through' : 'none' }]}>{item}</Text></Pressable>)}</Surface><SectionHeader title="Plan timeline" /><View style={styles.timeline}>{result.timeline.map((item, index) => <View key={item.label} style={styles.timelineRow}><View style={styles.timelineRail}><View style={[styles.timelineDot, { backgroundColor: index === 0 ? colors.purple : colors.mutedForeground }]} />{index < result.timeline.length - 1 ? <View style={[styles.timelineLine, { backgroundColor: colors.border }]} /> : null}</View><View style={styles.timelineCopy}><Text style={[styles.timelineLabel, { color: colors.purple }]}>{item.label}</Text><Text style={[styles.timelineDetail, { color: colors.foreground }]}>{item.detail}</Text></View></View>)}</View><SectionHeader title="AI matched professionals" action="See all" onAction={() => router.push('/discover')} />{professionals.slice(0, 2).map((pro) => <ProCard key={pro.id} pro={pro} onPress={() => router.push({ pathname: '/pro/[id]', params: { id: pro.id } })} />)}<PrimaryButton title="Start a new plan" secondary onPress={() => setResult(null)} /></View>}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { paddingHorizontal: 20, gap: 16 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  kicker: { fontSize: 10, fontWeight: '800', letterSpacing: 1.5 },
  title: { fontSize: 28, fontWeight: '700', letterSpacing: -1 },
  intro: { borderRadius: 24, padding: 18, gap: 10 },
  introIcon: { width: 42, height: 42, borderRadius: 15, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(155,123,255,0.18)' },
  introTitle: { fontSize: 20, lineHeight: 25, fontWeight: '700', maxWidth: 280 },
  introDetail: { fontSize: 13, lineHeight: 19 },
  label: { fontSize: 14, fontWeight: '700', marginTop: 3 },
  pills: { gap: 8 },
  prompt: { minHeight: 130, borderWidth: 1, borderRadius: 20, padding: 16, textAlignVertical: 'top', fontSize: 14, lineHeight: 21 },
  metaRow: { flexDirection: 'row', justifyContent: 'space-between' },
  meta: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  metaText: { fontSize: 11 },
  result: { gap: 16 },
  resultTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  resultTitle: { fontSize: 22, fontWeight: '700', marginTop: 5 },
  match: { width: 58, height: 58, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  matchNumber: { fontSize: 17, fontWeight: '800' },
  matchLabel: { fontSize: 10 },
  cardKicker: { fontSize: 10, fontWeight: '800', letterSpacing: 1.2 },
  budget: { fontSize: 30, fontWeight: '700', marginVertical: 8 },
  budgetLine: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 5 },
  budgetLabel: { fontSize: 12 },
  budgetValue: { fontSize: 12, fontWeight: '700' },
  progress: { height: 6, borderRadius: 10, marginTop: 10, overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 10 },
  checkRow: { flexDirection: 'row', alignItems: 'center', gap: 11, paddingVertical: 8 },
  checkbox: { width: 22, height: 22, borderWidth: 1.5, borderRadius: 7, alignItems: 'center', justifyContent: 'center' },
  checkText: { fontSize: 13, flex: 1 },
  timeline: { gap: 2 },
  timelineRow: { flexDirection: 'row', minHeight: 68 },
  timelineRail: { width: 28, alignItems: 'center' },
  timelineDot: { width: 10, height: 10, borderRadius: 5, marginTop: 4 },
  timelineLine: { width: 1, flex: 1, marginTop: 3 },
  timelineCopy: { flex: 1, gap: 5, paddingLeft: 8 },
  timelineLabel: { fontSize: 11, fontWeight: '800', textTransform: 'uppercase', letterSpacing: 0.6 },
  timelineDetail: { fontSize: 13, lineHeight: 18 },
});