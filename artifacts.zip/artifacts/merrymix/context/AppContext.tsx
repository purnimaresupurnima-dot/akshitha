import AsyncStorage from '@react-native-async-storage/async-storage';
import { Appearance } from 'react-native';
import React, { createContext, ReactNode, useContext, useEffect, useMemo, useState } from 'react';
import { Booking, defaultPlan, EventPlan } from '@/lib/merrymix-data';

type AppContextValue = {
  savedIds: string[];
  followedIds: string[];
  likedIds: string[];
  teamIds: string[];
  bookings: Booking[];
  plan: EventPlan | null;
  themeMode: 'light' | 'dark';
  toggleSaved: (id: string) => void;
  toggleFollowed: (id: string) => void;
  toggleLiked: (id: string) => void;
  addToTeam: (id: string) => void;
  removeFromTeam: (id: string) => void;
  addBooking: (booking: Booking) => void;
  savePlan: (plan: EventPlan) => void;
  toggleTheme: () => void;
};

const STORAGE_KEY = 'merrymix-local-state';
const AppContext = createContext<AppContextValue | null>(null);

type Persisted = Omit<AppContextValue, 'toggleSaved' | 'toggleFollowed' | 'toggleLiked' | 'addToTeam' | 'removeFromTeam' | 'addBooking' | 'savePlan' | 'toggleTheme'>;

export function AppProvider({ children }: { children: ReactNode }) {
  const [savedIds, setSavedIds] = useState<string[]>([]);
  const [followedIds, setFollowedIds] = useState<string[]>([]);
  const [likedIds, setLikedIds] = useState<string[]>([]);
  const [teamIds, setTeamIds] = useState<string[]>(['royal-moments', 'dreamdecor']);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [plan, setPlan] = useState<EventPlan | null>(null);
  const [themeMode, setThemeMode] = useState<'light' | 'dark'>('dark');

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((raw) => {
      if (!raw) return;
      try {
        const stored = JSON.parse(raw) as Partial<Persisted>;
        if (stored.savedIds) setSavedIds(stored.savedIds);
        if (stored.followedIds) setFollowedIds(stored.followedIds);
        if (stored.likedIds) setLikedIds(stored.likedIds);
        if (stored.teamIds) setTeamIds(stored.teamIds);
        if (stored.bookings) setBookings(stored.bookings);
        if (stored.plan) setPlan(stored.plan);
        if (stored.themeMode) {
          setThemeMode(stored.themeMode);
          Appearance.setColorScheme(stored.themeMode);
        }
      } catch {
        setPlan(defaultPlan);
      }
    });
  }, []);

  useEffect(() => {
    const snapshot: Persisted = { savedIds, followedIds, likedIds, teamIds, bookings, plan, themeMode };
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(snapshot)).catch(() => undefined);
  }, [savedIds, followedIds, likedIds, teamIds, bookings, plan, themeMode]);

  const toggle = (setter: React.Dispatch<React.SetStateAction<string[]>>, id: string) => {
    setter((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  };

  const toggleTheme = () => {
    const next = themeMode === 'dark' ? 'light' : 'dark';
    setThemeMode(next);
    Appearance.setColorScheme(next);
  };

  const value = useMemo<AppContextValue>(() => ({
    savedIds,
    followedIds,
    likedIds,
    teamIds,
    bookings,
    plan,
    themeMode,
    toggleSaved: (id) => toggle(setSavedIds, id),
    toggleFollowed: (id) => toggle(setFollowedIds, id),
    toggleLiked: (id) => toggle(setLikedIds, id),
    addToTeam: (id) => setTeamIds((current) => current.includes(id) ? current : [...current, id]),
    removeFromTeam: (id) => setTeamIds((current) => current.filter((item) => item !== id)),
    addBooking: (booking) => setBookings((current) => [booking, ...current]),
    savePlan: (nextPlan) => setPlan(nextPlan),
    toggleTheme,
  }), [savedIds, followedIds, likedIds, teamIds, bookings, plan, themeMode]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
}