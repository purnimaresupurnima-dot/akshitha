import { ImageSourcePropType } from 'react-native';

export type Professional = {
  id: string;
  name: string;
  category: string;
  location: string;
  rating: number;
  reviews: number;
  experience: string;
  price: number;
  match: number;
  verified: boolean;
  specialty: string;
  bio: string;
  followers: string;
  image: ImageSourcePropType;
  cover: ImageSourcePropType;
  tags: string[];
};

export type Booking = {
  id: string;
  professionalId: string;
  professionalName: string;
  eventType: string;
  date: string;
  budget: number;
  status: 'Pending' | 'Accepted' | 'Completed';
};

export type EventPlan = {
  eventType: string;
  guests: number;
  budget: number;
  location: string;
  services: string[];
  theme: string;
  checklist: string[];
  timeline: { label: string; detail: string }[];
};

export const categories = [
  { name: 'Photography', icon: 'camera', color: '#6C65D9' },
  { name: 'Decoration', icon: 'aperture', color: '#B879D9' },
  { name: 'Catering', icon: 'coffee', color: '#C98B68' },
  { name: 'Music', icon: 'music', color: '#5C9EDB' },
  { name: 'Wedding', icon: 'heart', color: '#D97C9D' },
  { name: 'Corporate', icon: 'briefcase', color: '#5CAFA5' },
  { name: 'Birthdays', icon: 'gift', color: '#E1AC5F' },
];

export const professionals: Professional[] = [
  {
    id: 'royal-moments',
    name: 'Royal Moments',
    category: 'Photography',
    location: 'Hyderabad',
    rating: 4.9,
    reviews: 128,
    experience: '6 years',
    price: 15000,
    match: 94,
    verified: true,
    specialty: 'Candid wedding stories',
    bio: 'Cinematic stories for couples who want to remember how it felt, not just how it looked.',
    followers: '2.4k',
    image: require('../assets/images/photography.jpg'),
    cover: require('../assets/images/photography.jpg'),
    tags: ['Candid', 'Wedding', 'Editorial'],
  },
  {
    id: 'dreamdecor',
    name: 'DreamDecor Events',
    category: 'Decoration',
    location: 'Vijayawada',
    rating: 4.8,
    reviews: 94,
    experience: '8 years',
    price: 25000,
    match: 91,
    verified: true,
    specialty: 'Immersive floral worlds',
    bio: 'Turning a venue into a feeling with layered light, flowers, and thoughtful details.',
    followers: '1.8k',
    image: require('../assets/images/decoration.jpg'),
    cover: require('../assets/images/decoration.jpg'),
    tags: ['Florals', 'Luxury', 'Stage'],
  },
  {
    id: 'royal-feast',
    name: 'Royal Feast',
    category: 'Catering',
    location: 'Warangal',
    rating: 4.7,
    reviews: 76,
    experience: '10 years',
    price: 35000,
    match: 88,
    verified: true,
    specialty: 'Modern regional menus',
    bio: 'Menus that feel familiar, elevated, and generous enough to become part of the memory.',
    followers: '1.1k',
    image: require('../assets/images/celebration.jpg'),
    cover: require('../assets/images/celebration.jpg'),
    tags: ['Catering', 'Regional', 'Buffet'],
  },
  {
    id: 'glow-mehendi',
    name: 'Glow Mehendi Studio',
    category: 'Wedding',
    location: 'Hyderabad',
    rating: 4.9,
    reviews: 62,
    experience: '5 years',
    price: 8000,
    match: 86,
    verified: true,
    specialty: 'Fine-line bridal mehendi',
    bio: 'Intricate, joyful designs made for the camera and the stories behind them.',
    followers: '980',
    image: require('../assets/images/decoration.jpg'),
    cover: require('../assets/images/decoration.jpg'),
    tags: ['Bridal', 'Fine line', 'Custom'],
  },
  {
    id: 'beatwave',
    name: 'BeatWave Events',
    category: 'Music',
    location: 'Nizamabad',
    rating: 4.8,
    reviews: 51,
    experience: '7 years',
    price: 10000,
    match: 84,
    verified: true,
    specialty: 'Sound that moves rooms',
    bio: 'A full-service sound and DJ team for celebrations that stay on the dance floor.',
    followers: '740',
    image: require('../assets/images/celebration.jpg'),
    cover: require('../assets/images/celebration.jpg'),
    tags: ['DJ', 'Sound', 'Live'],
  },
  {
    id: 'spicecraft',
    name: 'SpiceCraft Chefs',
    category: 'Catering',
    location: 'Hyderabad',
    rating: 4.8,
    reviews: 113,
    experience: '9 years',
    price: 22000,
    match: 82,
    verified: false,
    specialty: 'Chef-led home feasts',
    bio: 'Warm, abundant menus for hosts who want to be at the table, not in the kitchen.',
    followers: '1.5k',
    image: require('../assets/images/celebration.jpg'),
    cover: require('../assets/images/celebration.jpg'),
    tags: ['Chef', 'Home', 'Family'],
  },
];

export const eventTypes = ['Wedding', 'Birthday', 'Engagement', 'Baby ceremony', 'Corporate'];

export const defaultPlan: EventPlan = {
  eventType: 'Birthday',
  guests: 80,
  budget: 100000,
  location: 'Hyderabad',
  services: ['Decoration', 'Catering', 'Photography', 'Music'],
  theme: 'Midnight garden',
  checklist: ['Lock the venue', 'Shortlist the caterer', 'Confirm the photographer', 'Share the invite', 'Finalize the music'],
  timeline: [
    { label: '30 days before', detail: 'Book the venue and send the first invite list.' },
    { label: '20 days before', detail: 'Finalize catering, decor, and entertainment.' },
    { label: '10 days before', detail: 'Confirm every professional and guest count.' },
    { label: 'Event day', detail: 'Enjoy the room. MerryMix keeps the details moving.' },
  ],
};