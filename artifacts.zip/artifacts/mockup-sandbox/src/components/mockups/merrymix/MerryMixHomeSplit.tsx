import { useEffect, useMemo, useState } from "react";
import type { ComponentType } from "react";
import {
  Aperture,
  ArrowRight,
  ArrowUpRight,
  Bookmark,
  BriefcaseBusiness,
  CalendarDays,
  Camera,
  Check,
  ChevronRight,
  Coffee,
  Compass,
  Gift,
  Heart,
  LayoutDashboard,
  MapPin,
  Music2,
  Plus,
  Search,
  Settings2,
  SlidersHorizontal,
  Sparkles,
  Star,
  UsersRound,
  X,
  UserRound,
  Bell,
} from "lucide-react";
import "./MerryMixHomeSplit.css";

type Icon = ComponentType<{ size?: number; className?: string }>;

type Professional = {
  id: string;
  name: string;
  category: string;
  location: string;
  rating: number;
  reviews: number;
  price: string;
  image: string;
  specialty: string;
};

const moods: { name: string; icon: Icon }[] = [
  { name: "Photography", icon: Camera },
  { name: "Decoration", icon: Aperture },
  { name: "Catering", icon: Coffee },
  { name: "Music", icon: Music2 },
  { name: "Wedding", icon: Heart },
];

const professionals: Professional[] = [
  {
    id: "royal-moments",
    name: "Royal Moments",
    category: "Photography",
    location: "Hyderabad",
    rating: 4.9,
    reviews: 128,
    price: "₹15,000",
    image: "/__mockup/images/merrymix-home-split-photography.jpg",
    specialty: "Candid wedding stories",
  },
  {
    id: "dreamdecor",
    name: "DreamDecor Events",
    category: "Decoration",
    location: "Vijayawada",
    rating: 4.8,
    reviews: 94,
    price: "₹25,000",
    image: "/__mockup/images/merrymix-home-split-decoration.jpg",
    specialty: "Immersive floral worlds",
  },
  {
    id: "royal-feast",
    name: "Royal Feast",
    category: "Catering",
    location: "Warangal",
    rating: 4.7,
    reviews: 76,
    price: "₹35,000",
    image: "/__mockup/images/merrymix-home-split-celebration.jpg",
    specialty: "Modern regional menus",
  },
];

const moodIcons: Record<string, Icon> = {
  Corporate: BriefcaseBusiness,
  Birthdays: Gift,
};

function MerryMixHomeSplit() {
  const [activeNav, setActiveNav] = useState("Home");
  const [activeMood, setActiveMood] = useState("All moods");
  const [saved, setSaved] = useState<string[]>([]);
  const [team, setTeam] = useState<string[]>([]);
  const [search, setSearch] = useState("");
  const [notice, setNotice] = useState("");
  const [showNotifications, setShowNotifications] = useState(false);
  const [selectedPro, setSelectedPro] = useState<Professional | null>(null);
  const [showPlanner, setShowPlanner] = useState(false);

  useEffect(() => {
    if (!notice) return;
    const timer = window.setTimeout(() => setNotice(""), 2400);
    return () => window.clearTimeout(timer);
  }, [notice]);

  const filteredPros = useMemo(() => {
    const query = search.trim().toLowerCase();
    return professionals.filter((pro) => {
      const moodMatches = activeMood === "All moods" || pro.category === activeMood;
      const searchMatches =
        !query ||
        `${pro.name} ${pro.category} ${pro.location} ${pro.specialty}`
          .toLowerCase()
          .includes(query);
      return moodMatches && searchMatches;
    });
  }, [activeMood, search]);

  const handleNav = (label: string) => {
    setActiveNav(label);
    if (label !== "Home") setNotice(`${label} is ready for your next step`);
  };

  const toggleSaved = (id: string) => {
    setSaved((current) =>
      current.includes(id)
        ? current.filter((item) => item !== id)
        : [...current, id],
    );
    setNotice(saved.includes(id) ? "Removed from saved" : "Saved for later");
  };

  const toggleTeam = (id: string) => {
    setTeam((current) =>
      current.includes(id)
        ? current.filter((item) => item !== id)
        : [...current, id],
    );
    setNotice(team.includes(id) ? "Removed from your team" : "Added to your team");
  };

  const navItems: { label: string; icon: Icon }[] = [
    { label: "Home", icon: LayoutDashboard },
    { label: "Discover", icon: Compass },
    { label: "Planner", icon: CalendarDays },
    { label: "Bookings", icon: ClipboardListIcon },
    { label: "Profile", icon: UserRound },
  ];

  return (
    <main className="mm-split-shell">
      <div className="mm-split-layout">
        <aside className="mm-split-sidebar">
          <button className="mm-brand" type="button" onClick={() => handleNav("Home")}>
            <span className="mm-brand-mark">
              <Plus />
            </span>
            <span>
              Merry<span className="mm-brand-accent">Mix</span>
            </span>
          </button>

          <nav className="mm-nav" aria-label="Primary navigation">
            {navItems.map(({ label, icon: NavIcon }) => (
              <button
                className={`mm-nav-button ${activeNav === label ? "active" : ""}`}
                key={label}
                type="button"
                onClick={() => {
                  handleNav(label);
                  if (label === "Planner") setShowPlanner(true);
                }}
              >
                <NavIcon />
                <span>{label}</span>
              </button>
            ))}
          </nav>

          <div className="mm-sidebar-prompt">
            <strong>Planning feels lighter with a little magic.</strong>
            <p>Give us the feeling. We&apos;ll help shape the details.</p>
            <button type="button" onClick={() => setShowPlanner(true)}>
              Start a plan <ArrowUpRight />
            </button>
          </div>
        </aside>

        <section className="mm-split-main">
          <header className="mm-topbar">
            <div className="mm-location">
              <MapPin />
              <span>Hyderabad, India</span>
            </div>
            <div className="mm-top-actions">
              <button
                aria-label="Show notifications"
                className="mm-icon-button"
                type="button"
                onClick={() => setShowNotifications((current) => !current)}
              >
                <Bell />
              </button>
              <span className="mm-notification-dot" />
              <button
                aria-label="Open profile"
                className="mm-icon-button"
                type="button"
                onClick={() => handleNav("Profile")}
              >
                <UserRound />
              </button>
              {showNotifications ? (
                <div className="mm-notification-popover">
                  <strong>Your shortlist is looking good</strong>
                  <p>DreamDecor Events has fresh availability for your date.</p>
                </div>
              ) : null}
            </div>
          </header>

          <div className="mm-welcome">
            <div>
              <p className="mm-eyebrow">GOOD EVENING, ANANYA</p>
              <h1>Make it a moment worth remembering.</h1>
            </div>
            <p className="mm-welcome-note">
              <span>One calm place for the big picture.</span>
              Find the people, mood, and tiny details that make your event yours.
            </p>
          </div>

          <section className="mm-hero" aria-label="MerryMix AI planning">
            <div className="mm-hero-copy">
              <div>
                <p className="mm-kicker mm-hero-kicker">MERRYMIX AI</p>
                <h2>Your event, beautifully planned.</h2>
                <p>Tell us the feeling you want. We&apos;ll shape the details around it.</p>
              </div>
              <button className="mm-hero-cta" type="button" onClick={() => setShowPlanner(true)}>
                Plan with AI <ArrowUpRight />
              </button>
            </div>
            <div className="mm-hero-visual">
              <img
                alt="Friends celebrating together"
                className="mm-hero-image"
                src="/__mockup/images/merrymix-home-split-celebration.jpg"
              />
              <div className="mm-match-badge">
                <Star />
                <span>94% match</span>
              </div>
            </div>
          </section>

          <div className="mm-toolbar">
            <label className="mm-search">
              <Search />
              <input
                aria-label="Search professionals"
                onChange={(event) => setSearch(event.target.value)}
                placeholder="What are you looking for?"
                type="search"
                value={search}
              />
            </label>
            <button
              aria-label="Open filters"
              className="mm-filter-button"
              type="button"
              onClick={() => setNotice("Filters are tuned to your mood")}
            >
              <SlidersHorizontal />
            </button>
          </div>

          <section aria-labelledby="mood-heading">
            <div className="mm-section-heading">
              <h3 id="mood-heading">Explore by mood</h3>
              <button type="button" onClick={() => setNotice("Showing every mood")}>
                See all <ChevronRight />
              </button>
            </div>
            <div className="mm-mood-row">
              {[{ name: "All moods", icon: Sparkles }, ...moods].map(({ name, icon: MoodIcon }) => (
                <button
                  className={`mm-mood ${activeMood === name ? "active" : ""}`}
                  key={name}
                  type="button"
                  onClick={() => setActiveMood(name)}
                >
                  <MoodIcon />
                  <span>{name}</span>
                </button>
              ))}
            </div>
          </section>

          <div className="mm-content-grid">
            <section aria-labelledby="trending-heading">
              <div className="mm-section-heading">
                <h3 id="trending-heading">Trending near you</h3>
                <button type="button" onClick={() => setNotice("You are seeing the best local matches")}>
                  View all <ChevronRight />
                </button>
              </div>
              <div className="mm-pro-list">
                {filteredPros.length ? (
                  filteredPros.map((pro) => (
                    <article className="mm-pro-card" key={pro.id} onClick={() => setSelectedPro(pro)}>
                      <img alt="" className="mm-pro-image" src={pro.image} />
                      <div className="mm-pro-info">
                        <h4>{pro.name}</h4>
                        <div className="mm-pro-meta">
                          <strong>{pro.category}</strong>
                          <span>•</span>
                          <span>{pro.location}</span>
                        </div>
                        <p className="mm-pro-specialty">{pro.specialty}</p>
                        <div className="mm-pro-bottom">
                          <span className="mm-rating">
                            <Star />
                            {pro.rating} <span style={{ color: "var(--mm-muted)", fontWeight: 500 }}>({pro.reviews})</span>
                          </span>
                          <span className="mm-price">From {pro.price}</span>
                        </div>
                      </div>
                      <div className="mm-card-actions">
                        <button
                          aria-label={saved.includes(pro.id) ? `Remove ${pro.name} from saved` : `Save ${pro.name}`}
                          className={`mm-save-button ${saved.includes(pro.id) ? "saved" : ""}`}
                          type="button"
                          onClick={(event) => {
                            event.stopPropagation();
                            toggleSaved(pro.id);
                          }}
                        >
                          <Bookmark />
                        </button>
                        <button
                          className={`mm-add-button ${team.includes(pro.id) ? "added" : ""}`}
                          type="button"
                          onClick={(event) => {
                            event.stopPropagation();
                            toggleTeam(pro.id);
                          }}
                        >
                          {team.includes(pro.id) ? <Check /> : <Plus />}
                          <span>{team.includes(pro.id) ? "In team" : "Add to team"}</span>
                        </button>
                      </div>
                    </article>
                  ))
                ) : (
                  <div className="mm-team-card">
                    <div className="mm-team-icon"><Search /></div>
                    <h4>No exact matches yet</h4>
                    <p>Try another mood or a softer search. Your perfect fit is nearby.</p>
                    <button type="button" onClick={() => { setSearch(""); setActiveMood("All moods"); }}>
                      Clear filters <ArrowRight />
                    </button>
                  </div>
                )}
              </div>
            </section>

            <aside className="mm-side-stack">
              <div className="mm-team-card">
                <div className="mm-team-icon"><UsersRound /></div>
                <h4>Build your event team</h4>
                <p>{team.length} professionals selected · {team.length ? "Your shortlist is taking shape" : "Start with a recommendation"}</p>
                <button type="button" onClick={() => handleNav("Bookings")}>
                  Open team <ArrowRight />
                </button>
              </div>
              <button className="mm-inspiration" type="button" onClick={() => setNotice("Midnight garden added to your inspiration")}>
                <img alt="Midnight garden event decoration" src="/__mockup/images/merrymix-home-split-decoration.jpg" />
                <span className="mm-inspiration-copy">
                  <p>THEME OF THE WEEK</p>
                  <h4>Midnight garden</h4>
                  <span>Indigo florals · Candlelight · Silk details</span>
                </span>
              </button>
            </aside>
          </div>
        </section>
      </div>

      <nav className="mm-bottom-nav" aria-label="Mobile navigation">
        {navItems.slice(0, 4).map(({ label, icon: NavIcon }) => (
          <button className={activeNav === label ? "active" : ""} key={label} type="button" onClick={() => { handleNav(label); if (label === "Planner") setShowPlanner(true); }}>
            <NavIcon />
            <span>{label}</span>
          </button>
        ))}
        <button className={activeNav === "Profile" ? "active" : ""} type="button" onClick={() => handleNav("Profile")}>
          <Settings2 />
          <span>More</span>
        </button>
      </nav>

      {notice ? <div className="mm-toast" role="status">{notice}</div> : null}

      {selectedPro ? (
        <div className="mm-detail-backdrop" role="presentation" onClick={() => setSelectedPro(null)}>
          <div className="mm-detail-dialog" role="dialog" aria-modal="true" aria-label={`${selectedPro.name} details`} onClick={(event) => event.stopPropagation()}>
            <img alt="" className="mm-detail-image" src={selectedPro.image} />
            <div className="mm-detail-body">
              <button aria-label="Close professional details" className="mm-detail-close" type="button" onClick={() => setSelectedPro(null)}>
                <X />
              </button>
              <p className="mm-kicker">{selectedPro.category}</p>
              <h3>{selectedPro.name}</h3>
              <p>{selectedPro.location} · {selectedPro.rating} rating · {selectedPro.reviews} reviews</p>
              <p className="mm-detail-detail">{selectedPro.specialty}. A thoughtful fit for celebrations that should feel personal, not produced.</p>
              <button className="mm-detail-action" type="button" onClick={() => { toggleTeam(selectedPro.id); setSelectedPro(null); }}>
                {team.includes(selectedPro.id) ? "Remove from team" : "Add to your team"}
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {showPlanner ? (
        <div className="mm-detail-backdrop" role="presentation" onClick={() => setShowPlanner(false)}>
          <div className="mm-detail-dialog" role="dialog" aria-modal="true" aria-label="Plan with MerryMix AI" onClick={(event) => event.stopPropagation()}>
            <div className="mm-detail-body">
              <button aria-label="Close planner" className="mm-detail-close" type="button" onClick={() => setShowPlanner(false)}>
                <X />
              </button>
              <p className="mm-kicker">MERRYMIX AI</p>
              <h3>What should it feel like?</h3>
              <p>Pick a starting point and we&apos;ll turn the feeling into a clear event plan.</p>
              <button className="mm-detail-action" type="button" onClick={() => { setShowPlanner(false); setNotice("Your birthday plan is taking shape"); }}>
                Start with a birthday <ArrowUpRight style={{ display: "inline", width: 14, verticalAlign: "middle" }} />
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </main>
  );
}

function ClipboardListIcon(props: { size?: number; className?: string }) {
  return <CalendarDays {...props} />;
}

export default MerryMixHomeSplit;